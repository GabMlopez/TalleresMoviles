import 'package:flutter/material.dart';
class FirebasePage extends StatefulWidget {
  const FirebasePage({super.key});

  @override
  State<FirebasePage> createState() => _FirebasePageState();
}

class _FirebasePageState extends State<FirebasePage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
